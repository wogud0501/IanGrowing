using UnityEngine;
using UnityEngine.InputSystem;
using IanGame.Commercial;
namespace IanGame {
[RequireComponent(typeof(Rigidbody2D),typeof(CircleCollider2D))]
public sealed class WorldPlayerMotor:MonoBehaviour {
 public LifeWorldController world;public SpriteRenderer sprite;public SpriteMotionLibrary motions;public CharacterIdentity identity;public Transform bodyVisual;public Vector2 Facing=Vector2.down;
 public InputActionAsset controls;
 [Min(1)] public float acceleration=40, braking=64;
 Rigidbody2D body;Vector2 input,velocity;float walkPhase;string pose="Idle";float poseStart;
 InputActionAsset runtimeControls;InputActionMap gameplay;InputAction move,interact,inventory,menu;
 Keyboard imeKeyboard;bool ownsIME,restoreIME;
 public bool TextInputFocused {get {var es=UnityEngine.EventSystems.EventSystem.current;if(es==null||es.currentSelectedGameObject==null)return false;var field=es.currentSelectedGameObject.GetComponent<TMPro.TMP_InputField>();return field!=null&&field.isFocused;}}
 public bool InteractPressed=>OwnsKeyboardFocus()&&interact!=null&&interact.WasPressedThisFrame();
 public bool InventoryPressed=>OwnsKeyboardFocus()&&inventory!=null&&inventory.WasPressedThisFrame();
 public bool MenuPressed=>OwnsKeyboardFocus()&&menu!=null&&menu.WasPressedThisFrame();
 public Vector2 Movement=>velocity;
 void OnEnable(){
  // Own a clone: enabling gameplay must never enable/disable EventSystem's UI map.
  if(controls==null){Debug.LogError("LifeWorld: gameplay InputActionAsset is missing.",this);return;}
  runtimeControls=Instantiate(controls);gameplay=runtimeControls.FindActionMap("World",true);
  move=gameplay.FindAction("Move",true);interact=gameplay.FindAction("Interact",true);
  inventory=gameplay.FindAction("Inventory",true);menu=gameplay.FindAction("Menu",true);gameplay.Enable();
 }
 void OnDisable(){RestoreIME();StopMotion();gameplay?.Disable();if(runtimeControls!=null)Destroy(runtimeControls);runtimeControls=null;gameplay=null;move=interact=inventory=menu=null;}
 void OnApplicationFocus(bool focused){if(!focused){RestoreIME();StopMotion();}}
 void GameplayIME(bool active){var keyboard=Keyboard.current;if(!active||keyboard!=imeKeyboard)RestoreIME();if(active&&keyboard!=null&&!ownsIME){imeKeyboard=keyboard;restoreIME=keyboard.imeSelected.isPressed;keyboard.SetIMEEnabled(false);ownsIME=true;}}
 void RestoreIME(){if(ownsIME&&imeKeyboard!=null&&imeKeyboard.added&&restoreIME)imeKeyboard.SetIMEEnabled(true);imeKeyboard=null;ownsIME=false;}
 void StopMotion(){input=velocity=Vector2.zero;if(body!=null)body.linearVelocity=Vector2.zero;}
 public Vector2 Position=>body==null?(Vector2)transform.position:body.position;
 void Awake(){body=GetComponent<Rigidbody2D>();body.gravityScale=0;body.freezeRotation=true;body.interpolation=RigidbodyInterpolation2D.Interpolate;}
 bool OwnsKeyboardFocus(){if(!Application.isFocused)return false;
 #if UNITY_EDITOR
  if(UnityEditor.EditorWindow.focusedWindow==null||UnityEditor.EditorWindow.focusedWindow.GetType().Name!="GameView")return false;
 #endif
  return true;
 }
 void Update(){bool controlling=world!=null&&world.CanControl&&OwnsKeyboardFocus();GameplayIME(controlling);input=Vector2.zero;if(controlling&&move!=null){input=Vector2.ClampMagnitude(move.ReadValue<Vector2>(),1);if(input.sqrMagnitude>.01f){Facing=input;walkPhase+=Time.deltaTime*9;}}
  bool walk=input.sqrMagnitude>.01f;float t=Time.unscaledTime-poseStart;float bob=pose=="Sleep"?0:walk?Mathf.Abs(Mathf.Sin(walkPhase))*.05f:Mathf.Sin(Time.unscaledTime*1.6f)*.012f;bodyVisual.localPosition=new Vector3(0,.95f+bob,0);bodyVisual.localRotation=Quaternion.Euler(0,0,pose=="Sleep"?78:pose=="Work"?Mathf.Sin(t*8)*2:pose=="Wash"||pose=="Shower"?Mathf.Sin(t*10)*3:walk?Mathf.Sin(walkPhase)*2:0);bodyVisual.localScale=new Vector3(1,pose=="Sit"||pose=="Eat"||pose=="Work"?.88f:1,1);sprite.flipX=Facing.x<-.1f;sprite.sortingOrder=1000-Mathf.RoundToInt(transform.position.y*100);
  if(pose=="Wake Up")bodyVisual.localScale=new Vector3(1,Mathf.Lerp(.65f,1,Mathf.Clamp01(t/.35f)),1);
  if(motions!=null){SpriteMotion state=pose=="Sleep"?SpriteMotion.Sleep:pose=="Eat"?SpriteMotion.Eat:pose=="Work"?SpriteMotion.Work:walk?SpriteMotion.Walk:SpriteMotion.Idle;var clip=motions.Find(state);sprite.sprite=clip!=null&&clip.frames.Length>0?clip.frames[Mathf.FloorToInt(t*clip.framesPerSecond)%clip.frames.Length]:motions.fallback;}
  if(identity!=null&&(pose=="Idle"||walk)){string direction=Mathf.Abs(Facing.x)>Mathf.Abs(Facing.y)?Facing.x<0?"west":"east":Facing.y>0?"north":"south";var directional=identity.State((walk?"walk-":"idle-")+direction);if(directional!=null&&directional!=identity.baseSprite)sprite.sprite=directional;}
 }
 void FixedUpdate(){if(world==null||!world.CanControl||!OwnsKeyboardFocus()){StopMotion();return;}float fatigue=world.Service.State.fatigue>85?.7f:1;Vector2 target=input*world.Service.rules.moveSpeed*fatigue;velocity=Vector2.MoveTowards(velocity,target,(input.sqrMagnitude>.001f?acceleration:braking)*Time.fixedDeltaTime);body.MovePosition(body.position+velocity*Time.fixedDeltaTime);}
 public void Warp(Vector2 point){if(body==null)body=GetComponent<Rigidbody2D>();StopMotion();body.position=point;transform.position=point;}
 public void Pose(string state){pose=state;poseStart=Time.unscaledTime;}
}
}
