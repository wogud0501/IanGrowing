using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.InputSystem;
namespace IanGame {
[DefaultExecutionOrder(-50)]
public sealed class LifeWorldController:MonoBehaviour {
 public WorldPlayerMotor Player;public WorldCameraController follow;public WorldHUD hud;public WorldInteractable[] objects;
 public GameObject upgradedHome,starterWritingDesk;public Transform furnishingRoot;public WorldLifeAudio audio;public LifeWorldService Service{get;private set;}public WorldZoneDefinition CurrentZone{get;private set;}
 public bool Busy=>acting||travelling;public bool CanControl=>Service!=null&&!Busy&&Service.Game.State==GameState.Playing&&!Service.Game.BirthIntroductionPending&&hud.shell.Depth==0&&!Player.TextInputFocused&&!GameContext.Instance.transitions.IsTransitioning;
 public WorldInteractable Nearest{get;private set;}readonly List<WorldInteractable> furniture=new List<WorldInteractable>();string furnitureKey;bool acting,travelling,cancel;int restoreGeneration;Vector2 activityEntry;float nextLight;string restoreZone;Vector2 restoredPosition;
 readonly Dictionary<SpriteRenderer,Color> colors=new Dictionary<SpriteRenderer,Color>();public SpriteRenderer[] lamps;public WorldRoomBackdrop[] roomBackdrops=new WorldRoomBackdrop[0];
 void Awake(){if(GameContext.Instance==null)return;Service=GameContext.Instance.game.world;Service.Attach(this);}
 void Start(){if(Service==null){UnityEngine.SceneManagement.SceneManager.LoadScene("Bootstrap");return;}Service.Restored+=ApplySavedState;Service.Game.economy.Changed+=RefreshFurniture;Service.Game.StateChanged+=StateChanged;foreach(var s in GetComponentsInChildren<SpriteRenderer>(true))if(s!=Player.sprite)colors[s]=s.color;ApplySavedState();RefreshFurniture();}
 void OnDisable(){if(Service==null)return;Service.Restored-=ApplySavedState;Service.Game.economy.Changed-=RefreshFurniture;Service.Game.StateChanged-=StateChanged;acting=travelling=false;Service.State.pendingAction="";Service.Game.clock.RealtimeSuppressed=Service.Game.idle.State.active;if(Player!=null){Player.GetComponent<CircleCollider2D>().enabled=true;Player.Pose("Idle");}Service.Detach(this);}
 void StateChanged(GameState state){if(state==GameState.Starting)cancel=true;}
 void Update(){if(Service==null||CurrentZone==null)return;Service.Game.clock.RealtimeSuppressed=Busy||Service.Game.idle.State.active||hud.shell.Depth>0;Detect();if(CanControl&&Player.InteractPressed&&Nearest!=null)Use(Nearest);if(Time.unscaledTime>=nextLight){nextLight=Time.unscaledTime+.25f;Light();}}
 void Detect(){WorldInteractable best=null;float distance=float.MaxValue;if(CanControl){foreach(var o in objects.Concat(furniture)){if(o==null||!o.isActiveAndEnabled||o.zone!=Service.State.zone)continue;float d=(Player.Position-o.Point).sqrMagnitude;if(d<=o.radius*o.radius&&d<distance){best=o;distance=d;}}}if(best==Nearest)return;if(Nearest!=null)Nearest.Select(false);Nearest=best;if(best!=null)best.Select(true);hud.Prompt(best==null?null:"[E] "+best.title);}
 public bool NearbyKind(WorldInteractionKind kind)=>objects.Any(o=>o.kind==kind&&IsInReach(o)); public bool NearbyNPC(string id)=>objects.Any(o=>o.kind==WorldInteractionKind.NPC&&o.npcId==id&&IsInReach(o)); public bool IsInReach(WorldInteractable o)=>o!=null&&o.isActiveAndEnabled&&o.zone==Service.State.zone&&Vector2.Distance(Player.Position,o.Point)<=o.radius+.05f;
 public bool Use(WorldInteractable o){if(!CanControl||!IsInReach(o))return false;switch(o.kind){case WorldInteractionKind.Door:StartCoroutine(DoorTravel(o));return true;case WorldInteractionKind.Fridge:case WorldInteractionKind.Work:case WorldInteractionKind.Study:case WorldInteractionKind.NPC:case WorldInteractionKind.FoodShop:hud.OpenContext(o);return true;case WorldInteractionKind.FurnitureShop:hud.OpenHousing();return true;case WorldInteractionKind.StockMarket:return GameContext.Instance.transitions.Navigate(SceneId.StockMarket);case WorldInteractionKind.Wardrobe:hud.Notify("검은 반팔 · 카고 바지 · 헤드폰\n공식 기본 복장을 착용 중입니다.");return true;default:return Begin(o);}}
 public int ActionFor(WorldInteractionKind kind)=>kind==WorldInteractionKind.Sleep?5:kind==WorldInteractionKind.Meal?3:kind==WorldInteractionKind.Drink?4:kind==WorldInteractionKind.Rest?1:-1;
 public bool TryLegacyAction(int action){WorldInteractionKind kind=action==0||action>=20?WorldInteractionKind.Work:action>=7&&action!=9&&action!=18&&action!=19?WorldInteractionKind.Study:action==9||action==18||action==19?WorldInteractionKind.NPC:action==5?WorldInteractionKind.Sleep:action==3?WorldInteractionKind.Meal:action==4?WorldInteractionKind.Drink:WorldInteractionKind.Rest;var o=objects.Concat(furniture).FirstOrDefault(x=>x.kind==kind&&IsInReach(x));if(o==null){hud.Notify("해당 사물이나 사람에게 가까이 가서 [E]로 행동하세요.");return false;}return Begin(o,action);}
 public bool CanBegin(WorldInteractable o,int action,string food,out string reason){reason=null;if(Service.Game.State!=GameState.Playing||Service.Game.BirthIntroductionPending||Busy||!IsInReach(o)){reason="사물 가까이에서 정상 플레이 중에 사용하세요.";return false;}
  if(o.kind==WorldInteractionKind.FoodShop&&(Service.Hour<Service.rules.shopOpen||Service.Hour>=Service.rules.shopClose)){reason=$"영업 시간 {Service.rules.shopOpen:00}:00–{Service.rules.shopClose:00}:00";return false;}
  if(o.kind==WorldInteractionKind.FoodShop&&action==-3&&Service.State.fatigue>90){reason="먼저 침대에서 충분히 쉬세요.";return false;}
  if(o.kind==WorldInteractionKind.FoodShop&&action==3&&Service.State.bread<1){reason="먹을 빵이 없습니다. 빵을 구매하세요.";return false;}
  if(o.kind==WorldInteractionKind.Meal&&string.IsNullOrEmpty(Service.State.prepared)){reason="먼저 냉장고에서 음식을 골라 준비하세요.";return false;}
  if(o.kind==WorldInteractionKind.Fridge&&(food!="rice"&&food!="bread"||food=="rice"&&Service.State.rice<1||food=="bread"&&Service.State.bread<1||!string.IsNullOrEmpty(Service.State.prepared))){reason="음식이 없거나 이미 준비한 식사가 있습니다.";return false;}
  if(o.kind==WorldInteractionKind.NPC)Service.Game.phase23.SelectedNpcId=o.npcId;
  if(action>=0&&!Service.Game.CanPerformAction(action,out reason))return false;return true;
 }
 public bool Begin(WorldInteractable o,int action=-2,string food=""){if(action==-2)action=ActionFor(o.kind);string reason;if(!CanBegin(o,action,food,out reason)){hud.Notify(reason,2);return false;}hud.CloseContext();while(hud.shell.Depth>0){int depth=hud.shell.Depth;hud.shell.Pop();if(hud.shell.Depth==depth)return false;}Player.Facing=o.kind==WorldInteractionKind.Sleep?Vector2.down:((Vector2)o.transform.position-Player.Position).normalized;StartCoroutine(Activity(o,action,food));return true;}
 IEnumerator Activity(WorldInteractable o,int action,string food){acting=true;cancel=false;int generation=restoreGeneration;activityEntry=Player.Position;Service.State.pendingAction=o.kind.ToString();var collider=Player.GetComponent<CircleCollider2D>();bool sleep=o.kind==WorldInteractionKind.Sleep;string pose=sleep?"Sleep":o.kind==WorldInteractionKind.Meal?"Eat":o.kind==WorldInteractionKind.Shower?"Shower":o.kind==WorldInteractionKind.Wash?"Wash":o.kind==WorldInteractionKind.Work?"Work":o.kind==WorldInteractionKind.Rest||o.kind==WorldInteractionKind.Toilet?"Sit":"Interact";
  Player.Pose(pose);if(o.activityEffect!=null)o.activityEffect.SetActive(true);if(sleep){collider.enabled=false;Player.Warp((Vector2)o.transform.position+Vector2.up*.1f);}float duration=Mathf.Max(.1f,Service.rules.activityAnimationScale*(sleep?3.6f:action==0?5:1.7f));
  try{for(float t=0;t<duration;){if(cancel||!o.gameObject.activeInHierarchy)yield break;if(Service.Game.State==GameState.Paused){yield return null;continue;}t+=Time.unscaledDeltaTime;if(o.activityEffect!=null)for(int i=0;i<o.activityEffect.transform.childCount;i++)o.activityEffect.transform.GetChild(i).localPosition=new Vector3(-.3f+i*.15f,1.6f-Mathf.Repeat(t*2+i*.2f,.8f),-.01f);hud.Activity(o.title,t/duration);if(sleep)hud.Dim(Mathf.Sin(t/duration*Mathf.PI)*.9f);yield return null;}
   Service.State.pendingAction="";string message;bool ok=Service.Durable(()=>{if(o.kind==WorldInteractionKind.FoodShop&&action==-3){int reward=Service.rules.neighbourhoodHelpReward;if(!Service.Game.economy.Earn(reward,"동네 가게 정리"))return false;Service.Game.clock.AdvanceSimulation(Service.rules.neighbourhoodHelpMinutes*60);Service.State.dailyIncome+=reward;Service.State.fatigue=Mathf.Min(100,Service.State.fatigue+4);return true;}
    if(o.kind==WorldInteractionKind.FoodShop&&action==3){if(Service.State.bread<1)return false;Service.State.bread--;}
    if(o.kind==WorldInteractionKind.Meal){if(string.IsNullOrEmpty(Service.State.prepared))return false;Service.State.prepared="";}
    if(o.kind==WorldInteractionKind.Fridge){if(food=="rice"){if(Service.State.rice<1)return false;Service.State.rice--;}else{if(Service.State.bread<1)return false;Service.State.bread--;}Service.State.prepared=food;Service.Game.clock.AdvanceSimulation(food=="rice"?20*60:5*60);return true;}
    if(action>=0)return Service.CommitAction(action);
    double seconds=o.kind==WorldInteractionKind.Shower?20*60:o.kind==WorldInteractionKind.Toilet?8*60:5*60;Service.Game.clock.AdvanceSimulation(seconds);Service.State.hygiene=Mathf.Clamp(Service.State.hygiene+(o.kind==WorldInteractionKind.Shower?65:o.kind==WorldInteractionKind.Wash?15:5),0,100);Service.Game.stats.ApplyCore(new StatDelta{mental=2});return true;},out message);
   hud.Notify(ok?(sleep?"기상했습니다. "+Service.State.lastSummary:o.title+" 완료"):message);Player.Pose(sleep?"Wake Up":"Idle");if(sleep){var wakeFrom=Player.Position;var wakeTo=Safe(CurrentZone,activityEntry-CurrentZone.origin);for(float t=0;t<.35f;t+=Time.unscaledDeltaTime){if(cancel||generation!=restoreGeneration)yield break;Player.Warp(Vector2.Lerp(wakeFrom,wakeTo,Mathf.Clamp01(t/.35f)));yield return null;}}
  }finally{if(o!=null&&o.activityEffect!=null)o.activityEffect.SetActive(false);collider.enabled=true;if(generation==restoreGeneration)Player.Warp(Safe(CurrentZone,activityEntry-CurrentZone.origin));Player.Pose("Idle");Service.State.pendingAction="";acting=false;hud.Dim(0);hud.Activity(null,0);Service.Game.clock.RealtimeSuppressed=Service.Game.idle.State.active||hud.shell.Depth>0;}
 }
 public void CancelAction(){if(acting){cancel=true;hud.Notify("행동 취소 · 시간과 보상은 처리하지 않았습니다.",2);}}
 public bool PlacementClear(string id,Vector2 local,out string reason){
  reason=null;var rule=Service.Game.economy.housingCatalog.placementPlan?.Rule(id);if(rule==null)return true;var home=Service.rules.Zone("home");Physics2D.SyncTransforms();Vector2 p=home.origin+local;
  foreach(var col in Physics2D.OverlapBoxAll(p+Vector2.up*(rule.footprint.y/2),rule.footprint,0)){
   if(col.isTrigger)continue;var owner=col.GetComponentInParent<WorldInteractable>();if(owner!=null&&owner.id==id&&owner.name.StartsWith("Owned furniture"))continue;reason="이안이나 다른 가구와 겹치는 위치입니다.";return false;
  }
  foreach(var col in Physics2D.OverlapCircleAll(p+rule.approach,.3f)){
   if(col.isTrigger||col.attachedRigidbody==Player.GetComponent<Rigidbody2D>())continue;var owner=col.GetComponentInParent<WorldInteractable>();if(owner!=null&&owner.id==id&&owner.name.StartsWith("Owned furniture"))continue;reason="가구 앞에 접근할 수 있는 공간이 필요합니다.";return false;
  }
  return true;
 }
 IEnumerator DoorTravel(WorldInteractable door){var scale=door.transform.localScale;try{if(!Travel(door.targetZone,door.arrival))yield break;if(audio!=null)audio.OpenDoor();for(float t=0;door.animateDoorLeaf&&t<.14f;t+=Time.unscaledDeltaTime){door.transform.localScale=new Vector3(Mathf.Lerp(1,.18f,t/.14f)*scale.x,scale.y,scale.z);yield return null;}while(travelling)yield return null;}finally{if(door!=null)door.transform.localScale=scale;}} public bool Travel(string zone){var z=Service.rules.Zone(zone);return z!=null&&Travel(zone,z.spawn);}
 public bool Travel(string zone,Vector2 arrival){if(Busy||Service.Game.BirthIntroductionPending||Service.rules.Zone(zone)==null)return false;StartCoroutine(ChangeZone(zone,arrival));return true;}
 IEnumerator ChangeZone(string zone,Vector2 arrival){travelling=true;hud.CloseContext();for(float t=0;t<.16f;t+=Time.unscaledDeltaTime){hud.Dim(t/.16f);yield return null;}Service.State.zone=zone;CurrentZone=Service.rules.Zone(zone);Player.Warp(Safe(CurrentZone,arrival));Service.State.position=Player.Position-CurrentZone.origin;follow.Snap();RefreshFurniture();for(float t=0;t<.16f;t+=Time.unscaledDeltaTime){hud.Dim(1-t/.16f);yield return null;}hud.Dim(0);travelling=false;CapturePosition();string error;if(!Service.Game.SaveAutomaticCheckpoint(out error))hud.Notify("이동 상태 저장 실패 · 저장 메뉴에서 다시 시도하세요.");}
 public void CapturePosition(){if(CurrentZone==null||Service==null)return;Service.State.position=(acting?activityEntry:Player.Position)-CurrentZone.origin;Service.State.facing=Player.Facing;}
 public void ApplySavedState(){if(Service==null)return;restoreGeneration++;cancel=true;CurrentZone=Service.rules.Zone(Service.State.zone)??Service.rules.Zone("home");Service.State.zone=CurrentZone.id;RefreshFurniture();Player.Warp(Safe(CurrentZone,Service.State.position));Service.State.position=Player.Position-CurrentZone.origin;Player.Facing=Service.State.facing;follow.Snap();}
 public Vector2 Safe(WorldZoneDefinition zone,Vector2 local){local.x=Mathf.Clamp(local.x,-zone.size.x/2+.6f,zone.size.x/2-.6f);local.y=Mathf.Clamp(local.y,-zone.size.y/2+.6f,Mathf.Min(zone.size.y/2-.6f,zone.walkableTop-.65f));Vector2 p=zone.origin+local;if(Clear(p))return p;p=zone.origin+zone.spawn;if(Clear(p))return p;for(int y=-4;y<=4;y++)for(int x=-6;x<=6;x++){p=zone.origin+new Vector2(x,y);if(Clear(p))return p;}return zone.origin;}
 bool Clear(Vector2 p){foreach(var c in Physics2D.OverlapCircleAll(p,.32f))if(!c.isTrigger&&c.attachedRigidbody!=Player.GetComponent<Rigidbody2D>())return false;return true;}
 void RefreshFurniture(){
  if(Service==null||furnishingRoot==null)return;var housing=Service.Game.economy.Housing;bool improved=housing.residenceId=="improved";
  bool legacy=housing.starterRevision==0;
  if(upgradedHome!=null)upgradedHome.SetActive(legacy&&improved);if(starterWritingDesk!=null)starterWritingDesk.SetActive(legacy&&!improved);
  foreach(var o in objects)if(o!=null&&o.zone=="home"&&StarterHomePresentation.Optional(o.id))o.gameObject.SetActive(legacy&&(o!=starterWritingDesk?.GetComponent<WorldInteractable>()||!improved));
  GetComponent<StarterHomePresentation>()?.Apply(legacy);
  string key=JsonUtility.ToJson(housing);if(key==furnitureKey)return;furnitureKey=key;
  foreach(var previous in furniture)if(previous!=null){colors.Remove(previous.visual);Destroy(previous.gameObject);}furniture.Clear();
  var home=Service.rules.Zone("home");var catalog=Service.Game.economy.housingCatalog;
  foreach(var placement in housing.placed){
   var definition=catalog.Furniture(placement.id);if(definition==null||definition.preview==null)continue;var rule=catalog.placementPlan?.Rule(placement.id);
   var go=new GameObject("Owned furniture / "+placement.id);go.transform.SetParent(furnishingRoot,false);go.transform.position=home.origin+placement.position*2;
   var visual=new GameObject("Owned furniture sprite",typeof(SpriteRenderer));visual.transform.SetParent(go.transform,false);var renderer=visual.GetComponent<SpriteRenderer>();renderer.sprite=definition.preview;if(catalog.placementPlan!=null&&catalog.placementPlan.furnitureMaterial!=null)renderer.sharedMaterial=catalog.placementPlan.furnitureMaterial;
   float height=rule==null?Mathf.Min(2.4f,definition.preview.bounds.size.y*1.7f):rule.height;float scale=height/definition.preview.bounds.size.y;
   visual.transform.localScale=Vector3.one*scale;visual.transform.localPosition=Vector3.up*(-definition.preview.bounds.min.y*scale);renderer.sortingOrder=1000-Mathf.RoundToInt(go.transform.position.y*100);
   var collider=go.AddComponent<BoxCollider2D>();collider.size=rule==null?new Vector2(definition.preview.bounds.size.x*scale*.72f,.3f):rule.footprint;collider.offset=Vector2.up*(collider.size.y/2);
   var target=go.AddComponent<WorldInteractable>();target.id=placement.id;target.zone="home";target.title=definition.title+" 사용하기";target.kind=definition.interaction;target.visual=renderer;target.UsePoint=rule==null?Vector2.down*.9f:rule.approach;target.radius=Service.rules.interactionRadius;
   var highlight=new GameObject("Pixel highlight",typeof(SpriteRenderer));highlight.transform.SetParent(visual.transform,false);highlight.transform.localScale=Vector3.one*1.035f;var glow=highlight.GetComponent<SpriteRenderer>();glow.sprite=definition.preview;glow.sharedMaterial=renderer.sharedMaterial;glow.color=new Color(1,.85f,.3f,.35f);glow.sortingOrder=renderer.sortingOrder-1;glow.enabled=false;target.highlight=glow;
   if(Player.contactShadow!=null){var shadow=new GameObject("Contact shadow",typeof(SpriteRenderer));shadow.transform.SetParent(go.transform,false);var image=shadow.GetComponent<SpriteRenderer>();image.sprite=Player.contactShadow.sprite;image.sharedMaterial=Player.contactShadow.sharedMaterial;image.color=new Color(0,0,0,.22f);image.sortingOrder=renderer.sortingOrder-2;shadow.transform.localScale=new Vector3(collider.size.x/image.sprite.bounds.size.x,.22f/image.sprite.bounds.size.y,1);target.shadow=image;}
   furniture.Add(target);colors[renderer]=Color.white;
  }
  Physics2D.SyncTransforms();if(!Busy&&CurrentZone!=null&&!Clear(Player.Position))Player.Warp(Safe(CurrentZone,Player.Position-CurrentZone.origin));
 }
 void Light(){int hour=Service.Hour;foreach(var backdrop in roomBackdrops)if(backdrop!=null)backdrop.Apply(hour<6||hour>=19);float daylight=hour<5?.32f:hour<8?Mathf.Lerp(.32f,1,(hour-5)/3f):hour<18?1:hour<21?Mathf.Lerp(1,.32f,(hour-18)/3f):.32f;float ambient=CurrentZone.outdoor?daylight:Mathf.Max(.68f,daylight);foreach(var pair in colors)if(pair.Key!=null&&!lamps.Contains(pair.Key)){var c=pair.Value;pair.Key.color=new Color(c.r*ambient,c.g*ambient,c.b*Mathf.Lerp(ambient,1,.1f),c.a);}foreach(var lamp in lamps)if(lamp!=null)lamp.enabled=daylight<.7f;Player.sprite.color=Color.Lerp(new Color(.65f,.72f,.87f),Color.white,ambient);}
}
}
